
function CreateFileRefs()
{
var fr=new Array();
            
fr[1]=['urn:fatca:idessenderfilemetadata', 'urn_fatca_idessenderfilemetadata.html'];
fr[2]=['FATCA-IDES-SenderFileMetadata-1.1.xsd', 'fatca-ides-senderfilemetadata-1_1_xsd.html'];
fr[3]=['FATCAIDESSenderFileMetadataType', 'fatcaidessenderfilemetadatatype.html'];
fr[4]=['BinaryEncodingSchemeCd', 'binaryencodingschemecd.html'];
fr[5]=['FATCAEntCommunicationTypeCd', 'fatcaentcommunicationtypecd.html'];
fr[6]=['FATCAEntityReceiverId', 'fatcaentityreceiverid.html'];
fr[7]=['FATCAEntitySenderId', 'fatcaentitysenderid.html'];
fr[8]=['FATCAIDESSenderFileMetadata', 'fatcaidessenderfilemetadata.html'];
fr[9]=['FileCreateTs', 'filecreatets.html'];
fr[10]=['FileFormatCd', 'fileformatcd.html'];
fr[11]=['FileRevisionInd', 'filerevisionind.html'];
fr[12]=['OriginalIDESTransmissionId', 'originalidestransmissionid.html'];
fr[13]=['SenderContactEmailAddressTxt', 'sendercontactemailaddresstxt.html'];
fr[14]=['SenderFileId', 'senderfileid.html'];
fr[15]=['TaxYear', 'taxyear.html'];
fr[16]=['BinaryEncodingSchemeCdType', 'binaryencodingschemecdtype.html'];
fr[17]=['FATCAEntCommunicationTypeCdType', 'fatcaentcommunicationtypecdtype.html'];
fr[18]=['FATCAEntityIdType', 'fatcaentityidtype.html'];
fr[19]=['FileFormatCdType', 'fileformatcdtype.html'];
fr[20]=['String32Type', 'string32type.html'];
fr[21]=['StringMax200Type', 'stringmax200type.html'];
fr[22]=['StringMax5Type', 'stringmax5type.html'];
fr[23]=['TimestampWithMillisecondsType', 'timestampwithmillisecondstype.html'];
fr[24]=['YearType', 'yeartype.html'];    
 return fr;          
}

function CreateWordIndex()
{
var w=[
            
['base',[2,16,17,18,19,20,21,22,23,24]],
['components',[2]],
['fatca',[2,3,5,6,7,8,17,18]],
['ides',[2,3,8]],
['sender',[2,3,7,8,9,13,14]],
['file',[2,3,8,9,10,11,12,14,19]],
['metadata',[2,3,8]],
['2015-02-10',[2,5]],
['version',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]],
['created',[2,9]],
['updated',[2]],
['data',[2,17]],
['engineering',[2]],
['schema',[2]],
['xmlns',[2]],
['idessenderfilemetadata',[2]],
['http',[2]],
['xmlschema',[2]],
['xmime',[2]],
['xmlmime',[2]],
['targetnamespace',[2]],
['elementformdefault',[2]],
['qualified',[2]],
['attributeformdefault',[2]],
['unqualified',[2]],
['annotation',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]],
['appinfo',[2]],
['release',[2]],
['documentation',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]],
['component',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]],
['dictionaryentrynm',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]],
['majorversionnum',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]],
['minorversionnum',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]],
['versioneffectivebegindt',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]],
['versiondescriptiontxt',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]],
['descriptiontxt',[2,4,5,6,7,8,9,10,11,12,13,14,15,16,17,19,23,24]],
['element',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,20]],
['name',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]],
['fatcaidessenderfilemetadata',[2,8]],
['type',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]],
['fatcaidessenderfilemetadatatype',[2,3,8]],
['2014-08-29',[2,3,6,7,8,9,11,12,13,14,18,20,21,22]],
['initial',[2,3,4,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24]],
['containing',[2,8]],
['details',[2,8]],
['complextype',[2,3]],
['description',[2,3,18,20,21,22]],
['group',[2,3]],
['that',[2,3,9]],
['defines',[2,3]],
['information',[2,3,6,7]],
['contained',[2,3]],
['sequence',[2,3]],
['fatcaentitysenderid',[2,3,7,8]],
['fatcaentityreceiverid',[2,3,6,8]],
['fatcaentcommunicationtypecd',[2,3,5,8]],
['senderfileid',[2,3,8,14]],
['fileformatcd',[2,3,8,10]],
['minoccurs',[2,3]],
['binaryencodingschemecd',[2,3,4,8]],
['filecreatets',[2,3,8,9]],
['taxyear',[2,3,8,15]],
['filerevisionind',[2,3,8,11]],
['originalidestransmissionid',[2,3,8,12]],
['sendercontactemailaddresstxt',[2,3,8,13]],
['fatcaentityidtype',[2,6,7,18]],
['entity',[2,5,6,7,17,18]],
['identifier',[2,6,7,18]],
['identification',[2,6,7]],
['receiver',[2,6]],
['string32type',[2,12,20]],
['original',[2,12]],
['transmission',[2,9,12]],
['referential',[2,12]],
['stringmax200type',[2,13,14,21]],
['specified',[2,14]],
['timestampwithmillisecondstype',[2,9,23]],
['creation',[2,9]],
['timestamp',[2,9,23]],
['payload',[2,9]],
['application',[2,9]],
['boolean',[2,11]],
['revision',[2,11]],
['indicator',[2,11]],
['been',[2,11]],
['revised',[2,11]],
['fatcaentcommunicationtypecdtype',[2,5,17]],
['communication',[2,5,17]],
['code',[2,4,5,10,16,17,19]],
['communcation',[2,5]],
['contact',[2,13]],
['email',[2,13]],
['address',[2,13]],
['yeartype',[2,15,24]],
['reporting',[2,15]],
['year',[2,15,24]],
['2014-08-12',[2,15]],
['yyyy',[2,15,24]],
['format',[2,10,15,19,24]],
['fileformatcdtype',[2,10,19]],
['2015-03-05',[2,4,10,16,19]],
['binaryencodingschemecdtype',[2,4,16]],
['binary',[2,4,16]],
['encoding',[2,4,16]],
['scheme',[2,4,16]],
['content',[2,4]],
['simpletype',[2,16,17,18,19,20,21,22,23,24]],
['codes',[2,16,17,19]],
['restriction',[2,16,17,18,19,20,21,22,23,24]],
['string',[2,16,17,18,19,20,21,22,23]],
['enumeration',[2,16,17,19]],
['value',[2,16,17,18,19,20,21,22,23,24]],
['plain',[2,19]],
['text',[2,19]],
['rich',[2,19]],
['picture',[2,19]],
['jepg',[2,19]],
['none',[2,16]],
['special',[2,16]],
['base64',[2,16]],
['encoded',[2,16]],
['identificaton',[2,18]],
['entities',[2,18]],
['authoriites',[2,18]],
['financial',[2,18]],
['institutions',[2,18]],
['pattern',[2,18,23]],
['a-np-z0-9',[2,18]],
['a-np-z',[2,18]],
['2015-01-15',[2,17]],
['notification',[2,17]],
['report',[2,17]],
['competent',[2,17]],
['authority',[2,17]],
['request',[2,17]],
['registration',[2,17]],
['with',[2,20,21,22,23]],
['length',[2,20,21,22]],
['defining',[2,20,21,22]],
['usually',[2,20]],
['stringmax5type',[2,22]],
['maximum',[2,21,22]],
['minlength',[2,21,22]],
['maxlength',[2,21,22]],
['2008-01-08',[2,24]],
['gyear',[2,24]],
['mininclusive',[2,24]],
['maxinclusive',[2,24]],
['milliseconds',[2,23]],
['2009-03-11',[2,23]],
['true',[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]]
 ];
 return w;
}
        